Microsoft Azure SDK for Python
==============================

This is the Microsoft Azure Consumption Management Client Library.

Azure Resource Manager (ARM) is the next generation of management APIs that
replace the old Azure Service Management (ASM).

This package has been tested with Python 2.7, 3.4, 3.5 and 3.6.

For the older Azure Service Management (ASM) libraries, see
`azure-servicemanagement-legacy <https://pypi.python.org/pypi/azure-servicemanagement-legacy>`__ library.

For a more complete set of Azure libraries, see the `azure <https://pypi.python.org/pypi/azure>`__ bundle package.


Compatibility
=============

**IMPORTANT**: If you have an earlier version of the azure package
(version < 1.0), you should uninstall it before installing this package.

You can check the version using pip:

.. code:: shell

    pip freeze

If you see azure==0.11.0 (or any version below 1.0), uninstall it first:

.. code:: shell

    pip uninstall azure


Usage
=====

For code examples, see `Consumption Management
<https://docs.microsoft.com/python/api/overview/azure/consumption>`__
on docs.microsoft.com.


Provide Feedback
================

If you encounter any bugs or have suggestions, please file an issue in the
`Issues <https://github.com/Azure/azure-sdk-for-python/issues>`__
section of the project.


.. :changelog:

Release History
===============

2.0.0 (2018-02-06)
++++++++++++++++++

**Features**

- Marketplace data with and without billing period
- Price sheets data with and without billing period
- Budget CRUD operations support

**Breaking changes**
- Removing scope from usage_details, reservation summaries and details operations.

1.1.0 (2017-12-12)
++++++++++++++++++

**Features**

- Reservation summaries based on Reservation Order Id and/or ReservationId
- Reservation details based on Reservation Order Id and/or ReservationId

1.0.0 (2017-11-15)
++++++++++++++++++

**Features**

- Featuring stable api GA version 2017-11-30
- Supporting EA customers with azure consumption usage details

**Breaking changes**

- Removing support for calling usage_details.list() with 'invoice_id'. Will feature in future releases.

0.1.0 (2017-05-18)
++++++++++++++++++

* Initial Release


